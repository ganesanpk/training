 let name1 = "ABINASH";
 let letter = name1.at(0)
    console.log(letter);